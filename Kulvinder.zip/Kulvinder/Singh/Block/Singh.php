
<?php
namespace Kulvinder\Singh\Block;

class Singh extends \Magento\Framework\View\Element\Template
{
	public function _prepareLayout()
	{
		return parent::_prepareLayout();
	}
}
